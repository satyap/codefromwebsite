/* 	RC5 grapher v1.0 by Satya <http://satyaonline.cjb.net/>

	Requires:
	gd library from <http://www.boutell.com/gd/>
	C compiler (duh)

	To compile, use 'gcc -lgd rc5graph.c'
	Before compiling, check the #defines.
*/

#undef PNG
#undef GIF

/* select as appropriate */
/* #define DO_OUT_STUFF gdImagePng(im, out); */
#define DO_OUT_STUFF gdImageGif(im, out);

#include <gd.h>
#include <stdio.h>

/* image height max and min */
#define MAXH 400
#define MINH 100
/*width of each bar*/
#define WIDTH 4

int main(int argc,char *argv[]) {
	/* Declare the image */
	gdImagePtr im;
	/* Declare an output file */
	FILE *out,*in;
	/* Declare color indexes */
	int black,white;
	int i,x=20,y=20;
	int numblocks=0,height=0,maxheight=0,minheight=32767;
	char *imagefile;
	char *input;

	if(argc<2)	{
		printf("Usage:\n\t%s imagefile inputfile\n",argv[0]);
		exit(1);
	}

	imagefile=argv[1];
	input=argv[2];

	in=fopen(input,"r");
	while(!feof(in))	{
		numblocks++;
		fscanf(in,"%d",&height);
		if (height>maxheight)	maxheight=height;
		if (height<minheight)	minheight=height;
	}
	fclose(in);

	x=(numblocks-1)*WIDTH;
	y=maxheight-minheight;
	y=y>MAXH?MAXH:y;
	y=y<MINH?MINH:y; 

	im = gdImageCreate(x+2,y+2);
	white = gdImageColorAllocate(im, 255, 255, 255); /*background*/
	black = gdImageColorAllocate(im, 0, 0, 0);
	gdImageRectangle(im,0,0,x+1,y+1,black);

	numblocks=1;
	in=fopen(input,"r");
	for(i=0;i<x;i+=WIDTH)	{
		fscanf(in,"%d",&height);
/*height=(maxheight>MAXH?(height*MAXH/maxheight):(height));
height=(minheight<MINH?(height*MINH/maxheight):(height));*/
height=(height-minheight);
gdImageFilledRectangle(im,numblocks,y-height,numblocks+WIDTH,y,black);
numblocks+=WIDTH;
	}

	fclose(in);

	/* Open a file for writing. "wb" means "write binary", important
		under MSDOS, harmless under Unix. */
	out = fopen(imagefile, "wb");

	/* Output the image to the disk file. */
	DO_OUT_STUFF

	/* Close the file. */
	fclose(out);

       /* Destroy the image in memory. */
	gdImageDestroy(im);
}
 
/* eof */

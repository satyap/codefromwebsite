#!/usr/local/bin/perl

#Produces blockdata file in current directory, for rc5graph. 
#Version 1.0
#
# Always run before running rc5graph. Check the config.
#
#By Satya <http://satyaonline.cjb.net/>
#
#Freeware. Please keep these comments intact. Inform me of changes and
#redistribution. Give me credit if used anywhere.
 
$logfile='/home/satyap/logrc5';
$datafile='/home/httpd/cgi-bin/blockdata';

### End of configuration

open (LOG,"$logfile") || die "$!";
@lines=<LOG>;
close(LOG);

@month=("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
%revmonth=("Jan",0,"Feb",1,"Mar",2,"Apr",3,"May",4,"Jun",5,"Jul",6,"Aug",7,"Sep",8,"Oct",9,"Nov",10,"Dec",11);
%monday=(0,31,1,29,2,31,3,30,4,31,5,30,6,31,7,31,8,30,9,31,10,30,11,31);

$rcstmon=$rcemon=0;
for($i=0;$i<=$#lines;$i++)	{
	$lines[$i]=~s/\[//g;
	$_=$lines[$i];
	$find=/Completed RC5/o;
	if ($find>0)	{
		push(@rc,$lines[$i]);
		push(@rcrates,$lines[$i+1]);
	}
}

$total=$blocks=$day=0;$mon='';
foreach (@rc)	{
	@l=split(/ /,$_);
	if ($mon eq '')	{$mon=$l[0];$day=$l[1];}
#fencepost correction
	if ($l[1]==$day)	{
		@bar=split('\*',$l[8]) ;
		$bar[0]=~s/\(//;
		$blocks+=(2**$bar[0]);
				}
	else 	{
		$total+=$blocks;
		push (@rcblocks,$blocks);
		$mon=$l[0];$day=$l[1];
		$blocks=1;
		}
}

$total+=$blocks;
push (@rcblocks,$blocks);
#fencepost correction

open(OUT,">$datafile") or die "$!";
$blocks=join("\n",@rcblocks);
print OUT "$blocks";
close(OUT);


#EOF


To slow down the system, type:
	slow

To speed up again, type:
	fast

You only need the two .com files. The .asm files are Turbo Assembler
source code.

The programs only work in plain old DOS, not in Windows.

These programs work by disabling and enabling the L1 cache.

These are just something I wrote based on some assignments in college. If
it breaks, you keep all the pieces.

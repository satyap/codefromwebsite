#!/usr/bin/perl 

#rc5in.pl v1.0a
#
#See the RC5Warn entry at <http://satyaonline.cjb.net/download.html>
#
#When rc5 buff-in size in bytes is less than $limit, move the appropriate
#buff-in to that directory. This can even be made to cascade...
#Put it in crontab or something...
#
#Bugs: It really should do file locking, etc. It doesn't check permissions
#or anything. It's probably not very secure. CodingStyle sucks.
#
#Changed from 1.0: better output. more output. Rudimentary error checking.
#(File exists? is changed?)
#
#Race condition if rc5warn.pl hasn't locked itself properly. (IOW don't
#tamper with the rc5warn file. The flag file, that is.)
#
# Satya <http://satyaonline.cjb.net/>
#
#Use at own risk. Freeware. Please keep these comments intact. Inform me
#of changes and redistribution. Give me credit if used anywhere.

##begin config

#list of buff-in's to check
@buffin=(
'/f/net/in/distr/rc5/buff-in.rc5',
'/f/net/in/distr/rc5/buff-in.rc5',
'/f/net/in/distr/rc5/buff-in.rc5',

);

#move the corresponding files (these contain fresh, new buffers)
@newbuff=(
'/f/net/in/distr/rc5/win32cli/buff-in.rc5',
'/f/net/in/rc5/buff-in.rc5',
'/home/satyap/buff-in.rc5',

);

#set to non-zero for normal operation
$satya=0;

## end config

print "\nChecking for empty buff-in files...\n";

for($i=0;$i<=$#buffin;$i++)	{
$size=0;
$size=(stat($buffin[$i]))[7];
print "$buffin[$i] size is $size bytes.\n";
if($size<20)	{ #arbitrary
	print "Automatic change procedure initiated.\n";
	if (-e $newbuff[$i])	{
		print "Shifting $newbuff[$i] to $buffin[$i]\n";
		$output=`mv -vvvv $newbuff[$i] $buffin[$i]`;
		if ((stat($buffin[$i]))[7]<$size)	{
			print "ERROR: Wrong size. Command output:";
			print "\n---\n$output---\n";
			}
		}
	else	{
		print "$newbuff[$i] does not exist. Giving up.\n";
		}
	}

}#for

#while we're at it...

if ($satya==0)	{
print "\nOut buffers:\n";
$size=(stat('/f/net/in/distr/rc5/buff-out.rc5'))[7];
print "/f/net/in/distr/rc5/buff-out.rc5 size is $size\n";
}

#EOF

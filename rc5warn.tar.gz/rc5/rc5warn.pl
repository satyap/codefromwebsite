#!/usr/bin/perl 

use Socket;

#rc5warn.pl v1.4
#
#See the RC5Warn entry at <http://satyaonline.cjb.net/download.html>
#
#Warn when rc5 buff-in size in bytes is less than $limit and
#even fetch new blocks by email
#Put it in crontab or something...
#
#Changes v1.4: Used Philip Tellis' connectsocket() to open smtp
#		connection.
#
#Bugs: It really should do file locking, etc. It doesn't check permissions
#or anything. It's probably not very secure. CodingStyle sucks.
#
# Satya <http://satyaonline.cjb.net/>
#
#Use at own risk. Freeware. Please keep these comments intact. Inform me
#of changes and redistribution. Give me credit if used anywhere.

##begin config

#list of buff-in's to check
@buffin=(
'/f/net/in/distr/rc5/buff-in.rc5',
);

#1=fetch automatically, 0=just warn
@fetch=(1);

#buff-in filesizes, below which new blocks will be ordered
@limit=(1000);

@blocksize=(31);
@numblocks=(30);

#the contest specifier: 'rc5', 'csc' are the only ones supported afaik.
@contest=('rc5');

#fetch blocks to these addresses
@mailfrom=(
'satyap@bom2.vsnl.net.in',
);

#write log to this address
$maillog='satyap@localhost';
#and store stuff in this file
$flagfile='/home/satyap/rc5warn';

#address for email fetch
$mailto='fetch@distributed.net';

#end of line character
$EOL="\n";

#leave the rest alone unless you know what you're doing.
#HELO host for smtp.
$helo='localhost';
#mailhost
$host='localhost';
#mail port
$port=25;

## end config

my $reply='';

for($i=0;$i<=$#buffin;$i++)	{
$flag=0;
$size=0;
$size=(stat($buffin[$i]))[7];
print "$buffin[$i] size is $size threshold is $limit[$i]\n";

@locks=();
open(FLAG, "< $flagfile");
while(<FLAG>)	{
	$line=$_;
	if ($line eq "" || $line eq "\n") {next};
	chomp($line);
	push (@locks,$line);
	if ($line eq $buffin[$i]) {
		print "$buffin[$i] is locked... not ordering new blocks\n";
		$flag=1;
		}
	}
close(FLAG);

if ($flag==1) {
	if($size>=$limit[$i])	{ #if above threshold, remove lock
		print "$buffin[$i] renewed... removing lock\n";
		@lockswrite=();
		foreach $lock (@locks)	{
			unless ($lock eq $buffin[$i]){
				push(@lockswrite,$lock."\n");
				}
			}#foreach
		open(FLAG,"> $flagfile");
		print (FLAG "@lockswrite");
		close(FLAG);
		}#if $size>=$limit[$i]
	next;
	}#$flag

if($size<$limit[$i])	{
	print "$buffin[$i] limit reached\n";
if ($fetch[$i]==1)	{
	print "\tAutomatic fetch procedure initiated.\n";
	print "\tFetching $numblocks[$i]*2^$blocksize[$i] blocks...\n";
	&connectsocket($host,$port);
	print (MAIL "mail from: $mailfrom[$i]$EOL");
	$reply=<MAIL>;
	print MAIL "rcpt to: $mailto$EOL";
	$reply=<MAIL>;
	print MAIL "data$EOL";
	$reply=<MAIL>;
	print (MAIL "Subject: $buffin[$i] limit reached\n");
	print (MAIL "blocksize=$blocksize[$i]\n");
	print (MAIL "numblocks=$numblocks[$i]\n");
	print (MAIL "contest=$contest[$i]\n");
	print MAIL ".$EOL";
	$reply=<MAIL>;
	close(MAIL);
	#write lockfile
	open (LOCK,">> $flagfile");
	print (LOCK "$buffin[$i]\n");
	close(LOCK);
		}
else 	{ #if $fetch==0 i.e. don't fetch
	print "\$fetch==$fetch, not fetching.\n";
	}#else $fetch
	}#$size

}#for

exit;

sub connectsocket{
my $mailserver=shift || "localhost";
my $port = shift || 25;
my $iaddr = inet_aton($mailserver) or die "Could not resolve $mailserver:$!";
my $paddr = sockaddr_in($port, $iaddr);
my $proto = getprotobyname('tcp');
socket(MAIL, PF_INET, SOCK_STREAM, $proto) or
        die "Could not open client tcp socket: $!";
connect(MAIL, $paddr) or
        die "Could not connect socket to server: $mailserver:$port: $!";
while( ($reply = <MAIL>) =~ /^\d\d\d-/ ) {}
do {
        close MAIL or warn "Could not close socket with $mailserver: $!";
        die "Server did not respond with 220 on connect: $reply";
} if $reply !~ /^220/;
select MAIL; $|=1; select STDOUT;
print MAIL "helo $helo"."$EOL";
$reply=<MAIL>;
}



#EOF

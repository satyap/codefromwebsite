#settings for phonebook

#field lengths configured here. don't change, you'll need to create a new
#database file if you change these 4 settings
$name=50;
$addr=100;
$phone=40;
$email=60;

#datafile name
$phonebook='phonebook.dbf';

#script lock file
$lockfile='phonelocktmp.';

#temp file for delete script
$tempdel='phonedeltmp.';

$numfields=4;

#EOF

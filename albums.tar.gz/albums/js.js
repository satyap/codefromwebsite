document.onkeyup = function(evt) {
    var evt = (evt) ? evt : event;
    var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ?  evt.keyCode : ((evt.which) ? evt.which : 0));
    // H=72, L=76
    var link;
    if(charCode==72) {
        link=document.getElementById('prev');
    }
    if(charCode==76) {
        link=document.getElementById('next');
    }
    if(link) {
        document.location=link;
    }
}

var exifshow=0;

function exifmanip() {
    var exifmanip = document.getElementById('exifmanip');
    var exif = document.getElementById('exif');
    if(exifshow==0) {
        exifshow=1;
        exifmanip.innerHTML='Hide EXIF data';
        exif.style.display='block';
    }
    else {
        exifshow=0;
        exifmanip.innerHTML='Show EXIF data';
        exif.style.display='none';
    }
}

function toggle(elem) {
    var nodes = elem.parentNode.getElementsByTagName('ul');
    var i;
    var setter='none';
    var src='plus.gif';
    if(elem.src.substring(elem.src.length-8) == 'plus.gif') {
        setter='block';
        src='minus.gif';
    }

    elem.src=src;
    for(i=nodes.length-1;i>=0;i--) {
        // show or hide the sub-lists for the toggled block
        nodes[i].style.display=setter;
        if(setter=='block') { 
        // uhoh, collapse any sub-sub-lists...
            var childs = nodes[i].getElementsByTagName('img');
            var j;
            // ...by setting togglable images to collapsed state
            for(j=0;j<childs.length;j++) {
                if(childs[j].className=='toggle') { 
                    childs[j].src='plus.gif';
                }
            }
            // ...and hiding the sub-lists
            childs = nodes[i].getElementsByTagName('ul');
            for(j=0;j<childs.length;j++) { 
                    childs[j].style.display='none';
            }
        }
    }
}


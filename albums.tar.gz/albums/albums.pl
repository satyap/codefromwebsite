#!/usr/bin/perl
use strict;
use warnings;
use Image::Magick;
use HTML::Template;
#use XML::Simple;
use XML::LibXML;
use Image::Size qw(imgsize);
use Data::Dumper;
use Benchmark;
my $t1 = Benchmark->new;
require 'albums.conf';
$|=1;

our(
    $conf,
);
my $DEBUGLEVEL=$conf->{'debug'} || 2;

$conf->{'imagetmpl'}=HTML::Template->new(
    filename=> 'image.html',
    die_on_bad_params=>0,
    loop_context_vars => 1,
    blind_cache=>1,
);

$conf->{'dirtmpl'}=HTML::Template->new(
    filename=> 'dir.html',
    die_on_bad_params=>0,
    loop_context_vars => 1,
    blind_cache=>1,
);

$conf->{'children'}=0;
$conf->{'imgobj'} = new Image::Magick;
$conf->{'parser'} = new XML::LibXML;

&cp("style.css", $conf->{'outdir'}.'/style.css');
&cp("js.js", $conf->{'outdir'}.'/js.js');
&cp("plus.gif", $conf->{'outdir'}.'/plus.gif');
&cp("minus.gif", $conf->{'outdir'}.'/minus.gif');
&cp("nosub.gif", $conf->{'outdir'}.'/nosub.gif');
&cp("ar_l.png", $conf->{'outdir'}.'/ar_l.png');
&cp("ar_r.png", $conf->{'outdir'}.'/ar_r.png');
&cp("first.png", $conf->{'outdir'}.'/first.png');
&cp("last.png", $conf->{'outdir'}.'/last.png');

my $dirdata = &do_dir(
    conf=>$conf,
    indir=>$conf->{'indir'},
    outdir=>$conf->{'outdir'},
    httpdir => $conf->{'httpbase'},
    breadcrumb => [],
    #breadcrumb => [{url=>$conf->{'httpbase'},txt => 'Root'}],
    dirname => $conf->{'strings'}->{'albumroot'},
    dir => '.',
);

my $tree=HTML::Template->new(
    filename=>'tree.html',
    blind_cache => 1,
);
my @tree = &maketree([$dirdata]);
$tree->param(
    tree => \@tree,
    title => "Album tree",
    albumroot => $conf->{'strings'}->{'albumroot'},
    treeview => $conf->{'strings'}->{'treeview'},
    httpbase => $conf->{'httpbase'},
);
&writefile($conf->{'outdir'} . '/tree.html', $tree->output,0);

while(my $pid=wait) {
    last if $pid<0;
}

my $t2 = Benchmark->new;
print timestr(timediff($t2,$t1)) . "\n";

exit;

sub do_dir {
    my %args=@_;
    my $conf=$args{'conf'};
    my $indir=$args{'indir'};
    my $outdir=$args{'outdir'};
    my $dirname = $args{'dirname'};
    my $dir = $args{'dir'};
    my $httpdir = $args{'httpdir'};
    my $breadcrumb=$args{'breadcrumb'};
    &debug(1,"$indir\n");

    my @filedata=();
    my @dirdata=();

    opendir(DIR,$indir) || die "$indir: $!";
    my @dir = sort readdir(DIR);
    close(DIR);

    my $albumxml={};
    {
        my $xmlfile=$indir."/album.xml";
        if(-e $xmlfile) {
            ($albumxml, undef)=XMLin($conf,$xmlfile,0);
        }
    }

    $albumxml->{'title'}=($dirname || $dir) if not exists $albumxml->{'title'};
    $albumxml->{'dirname'}=$albumxml->{'title'};

    push(@$breadcrumb, {
            url => $httpdir,
            txt => $albumxml->{'title'},
        });

    my %datatopass=(
        conf => $conf,
        breadcrumb=>$breadcrumb,
    );

    foreach my $f (@dir) {
        next if substr($f,0,1) eq '.';
        my $in = $indir.'/'.$f;
        my $out = $outdir.'/'.$f;
        if(-d $in) {
            unless(-d $out) {
                mkdir($out) || die "$out: $!";
            }
            my $dirdata=&do_dir(
                indir=>$in,
                outdir=>$out,
                httpdir=>$httpdir.'/'.$f,
                dir=>$f,
                %datatopass,
            );
            $dirdata->{'dir'}=$f;
            push(@dirdata, $dirdata);
        }
        elsif(-f $in) {
            next unless $f=~/.(jpg|gif|png)$/;
            my $filedata=&handle_file(
                file=>$f,
                indir=>$indir,
                outdir=>$outdir,
                httpdir=>$httpdir,
                dir => $dir,
                %datatopass,
            );
            $filedata->{'dir'}=$dir;
            push(@filedata, $filedata);
        }
        else {
            print "$in: not a file or directory\n";
        }
        if($conf->{'children'} >= $conf->{'max_children'}) {
            wait;
            $conf->{'children'}--;
        }
    } # foreach file in dir

    while($conf->{'children'} >= $conf->{'max_children'}) {
        my $pid=wait;
        $conf->{'children'}--;
    }

    ($albumxml->{'sampleimage'},
        $albumxml->{'rawsample'},
        $albumxml->{'samplew'},
        $albumxml->{'sampleh'},
    )
    = &get_sampleimage($albumxml, \@filedata, \@dirdata, $dir);

    $albumxml->{'filecount'} = scalar @filedata;
    $albumxml->{'dircount'} = scalar @dirdata;

    my $imagetmpl=$conf->{'imagetmpl'};
    $conf->{'dirtmpl'}->clear_params;
    $conf->{'dirtmpl'}->param(
        filedata => \@filedata,
        dirdata => \@dirdata,
        %$albumxml,
        httpdir=>$httpdir,
        breadcrumb=>$breadcrumb,
        httpbase => $conf->{'httpbase'},
        albumroot => $conf->{'strings'}->{'albumroot'},
        treeview => $conf->{'strings'}->{'treeview'},
    );
    &writefile($outdir."/index.html", $conf->{'dirtmpl'}->output);

    for(my $i=0;$i<scalar @filedata;$i++) {
        my $f = $filedata[$i];
        my $next='';
        my $prev='';
        my $nexttext = $conf->{'strings'}->{'next'};
        my $prevtext = $conf->{'strings'}->{'prev'};
        $prev = $filedata[$i-1]->{'imagehttp'}; # if i=0, i=last
        if($i==0) {
            $prevtext = $conf->{'strings'}->{'last'};
        }
        if(exists $filedata[$i+1]) { # but i+1 != 0
            $next = $filedata[$i+1]->{'imagehttp'};
        }
        else {
            $next = $filedata[0]->{'imagehttp'};
            $nexttext = $conf->{'strings'}->{'first'};
        }
        $imagetmpl->clear_params;
        $imagetmpl->param(
            prevtext => $prevtext,
            nexttext => $nexttext,
            viewh=>$f->{'viewh'},
            vieww=>$f->{'vieww'},
            file => $f->{'file'},
            viewhttp => $f->{'viewhttp'},
            exif=> $f->{'exif'},
            breadcrumb => $f->{'breadcrumb'},
            %{ $f->{'picinfo'} },
            next => $next,
            prev => $prev,
            httpbase => $conf->{'httpbase'},
            albumroot => $conf->{'strings'}->{'albumroot'},
            treeview => $conf->{'strings'}->{'treeview'},
        );

        &writefile($f->{'imagefile'},$imagetmpl->output);
    } # foreach filedata

    pop @$breadcrumb;

    $albumxml->{'dirdata'} = \@dirdata;
    $albumxml->{'httpdir'} = $httpdir;

    return $albumxml;

} # do_dir

sub get_sampleimage() {
    my ($albumxml, $filedata, $dirdata, $dir) = @_;
    my ($samplew,$sampleh);

    # first we assume it is given to us. if it's not, it'll trickle up through
    # the first file or directory encountered.
    # if an explicit sample is given and it's in a sub-sub-dir, getting its
    # dimensions is a pain.
    my $sampleimage=$dir.'/'.($albumxml->{'sampleimage'} || '');

    if (substr($sampleimage,-1,1) eq '/') {
        # not given, get it from the first file, if there were any files
        if(exists($filedata->[0])) { # some dirs have subdirs but no files
            $sampleimage=$filedata->[0]->{'dir'}.'/'.$filedata->[0]->{'file'};
            $sampleh=$filedata->[0]->{'ph'};
            $samplew=$filedata->[0]->{'pw'};
        }
    }
    else {
        # already have a sample image, which should be in the filedata list
        foreach(@$filedata) {
            if($_->{'file'}=~/^(.+\/)?$sampleimage$/) {
                $sampleh = $_->{'ph'};
                $samplew = $_->{'pw'};
            }
        }
        # and if it's not, we'll have to search all of dirdata here...TODO
    }
    if (substr($sampleimage,-1,1) eq '/') {
        # not given, and not found one in the file list, so get the subdir's
        # sampleimage.
        #$sampleimage=$dirdata->[0]->{'dir'}.'/'.$dirdata->[0]->{'rawsample'};
        $sampleimage=$dir.'/'.$dirdata->[0]->{'rawsample'};
        $sampleh=$dirdata->[0]->{'sampleh'};
        $samplew=$dirdata->[0]->{'samplew'};
    }

    # store the original image name in case a parent dir needs it.
    my $rawsample=$sampleimage; 
    $sampleimage=~s/\.(\w+)$/_pre.$1/;

    return ($sampleimage, $rawsample, $samplew, $sampleh);

} # get_sampleimage


sub handle_file() {
    my %args=@_;
    my $file = $args{'file'};
    my $indir = $args{'indir'};
    my $outdir = $args{'outdir'};
    my $conf = $args{'conf'};
    my $httpdir = $args{'httpdir'};
    my $dir = $args{'dir'};
    my $breadcrumb = $args{'breadcrumb'};

    my $infile = $indir.'/'.$file;
    my $outfile = $outdir.'/'.$file;
    my $imagetmpl = $conf->{'imagetmpl'};

    my $viewfile=$outfile;
    my $previewfile=$outfile;
    my $imagefile=$outfile;
    my $xmlfile=$infile.'.xml';

    my $viewhttp=$file;
    my $previewhttp=$file;
    my $imagehttp=$file;

    $viewfile=~s/\.(\w+)$/_v.$1/;
    $previewfile=~s/\.(\w+)$/_pre.$1/;
    $imagefile=~s/\.(\w+)$/.html/;

    $viewhttp=~s/\.(\w+)$/_v.$1/;
    $previewhttp=~s/\.(\w+)$/_pre.$1/;
    $imagehttp=~s/\.(\w+)$/.html/;

    my ($picinfo, $exif) = ({},[]);
    if(-e $xmlfile) {
        ($picinfo, $exif)=XMLin($conf, $xmlfile,1);
    }
    $picinfo->{'title'}=$file unless (exists $picinfo->{'title'} && $picinfo->{'title'} ne '');

    #my ($ph,$pw)=&get_pre_size($conf,$imobj->Get('height','width'));
    my ($pw,$ph)=&get_pre_size($conf->{'preview_size'},imgsize($infile));
    my ($vw,$vh)=&get_pre_size($conf->{'view_size'},imgsize($infile));

    my $filedata={
        ph=>$ph,
        pw=>$pw,
        preview => $previewhttp,
        imagehttp => $imagehttp,
        %$picinfo,
        file=>$file,
        # image.html-specific stuff follows
        viewh=>$vh,
        vieww=>$vw,
        viewhttp => $viewhttp,
        exif=> $exif,
        breadcrumb => $breadcrumb,
        picinfo => $picinfo,
        imagefile => $imagefile,
    };
    # this next if() statement based on Bins. i had the idea, but i checked
    # bins' to see what they did.
    if(-e $outfile && ((lstat($outfile))[9] >= (lstat($infile))[9])) {
        return $filedata;
    }

    my $pid=fork;
    if($pid==0) {
        &debug(1,"Previewing $indir/$file\n");
        eval(unlink $outfile);
        eval(unlink $viewfile);
        eval(unlink $previewfile);

        my $imobj = $conf->{'imgobj'};
        $imobj->Read($infile);
        $imobj->Strip();
        $imobj->Write($outfile);
        my ($w, $h) = ($imobj->Get('width'),$imobj->Get('height'));
        if($w>$vw || $h>$vh) {
            $imobj->Resize($conf->{'view_size'});
        }
        $imobj->Write($viewfile);
        ($w, $h) = ($imobj->Get('width'),$imobj->Get('height'));
        if($w>$pw || $h>$vh) {
            $imobj->Resize($conf->{'preview_size'});
        }
        $imobj->Write($previewfile);

        exit;
    }
    if($pid>0) {$conf->{'children'}++;}
    return $filedata;

} # handle_file

sub debug() {
    my $lvl=shift;
    my @string=@_;
    if($lvl<=$DEBUGLEVEL) {
        print "@string";
    }
} # debug

sub cp() {
    my $src=shift;
    my $dst=shift;
    open(I,"<$src") || die "$0: $src: $!";
    open(O,">$dst") || die "$0: $dst: $!";
    my $buffer;
    binmode(I);
    binmode(O);
    while ( read (I, $buffer, 1024)) {
        print O $buffer;
    }
    close(I);
    close(O);

} # cp


sub writefile() {
    my $file=shift;
    my $content=shift;
    my $clean=shift||0;
    if($clean==0) {
        $content=~s/^\s*//gmo;
        $content=~s/\s*$//gmo;
        $content=~s/\n+/\n/gso;
    }
    local $/=undef;
    open(O,">$file") || warn "$file: $!";
    print O $content;
    close(O);
} # writefile

sub get_pre_size() {
    my $presize=shift;
    my $w=shift;
    my $h=shift;
    my ($pre_x,$pre_y) = split('x',$presize);
    return ($w, $h) if ($w<=$pre_x && $h<=$pre_y);
    my $ar = $w/$h; # aspect ratio
    my $ar_pre = $pre_x/$pre_y;
    my $factor;
    if($ar<$ar_pre) {
        $factor = $pre_y/$h;
    }
    else {
        $factor = $pre_x/$w;
    }
    my $ph = int($h*$factor);
    my $pw = int($w*$factor);

    return($pw,$ph);

} # get_pre_size

sub copyfile() {
    my $src=shift;
    my $dest=shift;
    open(I,"<$src") || warn "$!: $src";
    open(O,">$dest") || warn "$dest: $!";
    print O <I>;
    close(O);
    close(I);
} # sub copyfile

sub createfilefromtmpl() {
    my $tmpl = shift;
    my $out = shift;
    my $params = shift;
    my $template = HTML::Template->new(filename => $tmpl);
    foreach (keys %$params) {
        $template->param($_ => $params->{$_});
    }
    &writefile($out, $template->output, 1);
} # sub createfilefromtmpl

sub maketree() {
    my $dirdata=shift;
    my @ret = ();
    foreach my $dir (@$dirdata) {
        my $q={
            httpdir => $dir->{'httpdir'}, 
            title => $dir->{'title'},
        };
        my @list=();
        if($#{ $dir->{'dirdata'} } >= 0) { # handle sub-dirs
            @list = &maketree($dir->{'dirdata'});
            $q->{'startlist'}=1;
            # if a list has already ended, we have to have a second ending
            # because two nested lists are ending. i.e. @lists has a sublist at the end of it.
            if(exists $list[-1]->{'endlist'}) {
                push(@list, {endlist=>1});
            }
            else {
                $list[-1]->{'endlist'}=1;
                # httpdir is blank here, so we can use tmpl_if in the template
            }
        }
        else { # no subs
            $q->{'leaf'}=1;
        }
        push(@ret, $q);
        push(@ret, @list);
    }

    return @ret;
} # sub maketree

sub XMLin() {
    my $conf=shift;
    my $file = shift;
    my $wantexif=shift||1;
    my $doc=$conf->{'parser'}->parse_file($file);

    my $elems = $doc->documentElement;

    my $fields = &nodelist2hash($elems->findnodes('//description/field'));
    my @exif;
    if($wantexif) {
        my $exif = &nodelist2hash($elems->findnodes('//exif/tag'));
        foreach my $tag(sort keys %{ $exif }) {
            push(@exif, {name=>$tag, content=>$exif->{$tag}});
        }
    }

    return $fields, \@exif;   

} # XMLin

sub nodelist2hash() {
    my @nodes=@_;
    my $ret={};
    foreach my $field (@nodes) {
        foreach my $attr ($field->attributes) {
            if($attr->name eq 'name') {
                my $c = $field->textContent;
                $c=~s/^\s+//o;
                $c=~s/\s+$//o;
                $ret->{$attr->value} = $c;
            }
        }
    }
    return $ret;
} # nodelist2hash


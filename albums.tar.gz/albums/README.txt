albums.pl is a script that makes web-based albums from a BINS
(http://bins.sautret.org/ ) repository. See albums.conf. See the HTML files for
changing the look.

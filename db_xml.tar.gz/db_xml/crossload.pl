use strict;
use warnings;

use DBI;
use Data::Dumper;
require 'common.pl';
{package sysConf; do "rest.conf" or die "Can't read configuration file: rest"}
{package myConf; do "crossload.conf" or die "Can't read configuration file: crossload $!"}

foreach my $db1 (keys %{ $myConf::cross }) {
    my $dbh1 = connectDB($db1);
    foreach my $table1 (keys %{ $myConf::cross->{$db1} }) {
        my $tabledata=$myConf::cross->{$db1}->{$table1};
        # set up the various strings
        my @columns1 = keys %{ $tabledata->{'column_map'} }; # get the source columns
        my @columns2 = map{ $tabledata->{'column_map'}->{$_} } @columns1; # corresponding destination columns
        my $table2 = $tabledata->{'table'};
        my $placeholders=join(',', map{'?'}@columns2); # list of placeholders, joined by commas
        my $select = "SELECT * FROM $table1";
        my $truncate = "TRUNCATE $table2";
        my $columns2 = join(',',@columns2);
        my $insert = "INSERT INTO $table2 ($columns2) VALUES ($placeholders)";

        print "=== $table1 to ";
        print "$table2 ===\n";
        print "$select\n$insert\n$truncate\n";
        # start doing stuff
        my $dbh2 = connectDB(undef,$tabledata, 0);
        my $sth1 = $dbh1->prepare($select);
        $dbh2->do($truncate);
        $dbh2->do("LOCK TABLES $table2 WRITE");
        my $sth2 = $dbh2->prepare($insert);
        $sth1->execute;
        my $count=0;
        while(my $r=$sth1->fetchrow_hashref) {
            # Take the column names, index into the associative array $r, and
            # map out the values to pass to the execute.
            $sth2->execute( map { $r->{$_} } @columns1 );
            $count++;
            if($count % $tabledata->{'commit_interval'} == 0) {
                $dbh2->commit || warn "commit failed? $DBI::errstr";
                print "$count\n";
            }

        }
        $sth1->finish;
        $sth2->finish;
        $dbh2->disconnect;
    }
    $dbh1->disconnect;
}


sub connectDB() {
    # Pass in the key of the database definition, or just pass in the database definition:
    # connectDB(key) OR connectDB(undef, tableDefinition)
    my $db=shift;
    my $conf=shift || $sysConf::db->{$db};
    my $ac=shift;
    $ac=1 unless defined($ac);
    my $dbh = DBI->connect($conf->{'data_source'} . ";database=" . $conf->{'database'}, $conf->{'username'}, $conf->{'auth'}, {AutoCommit => $ac})
        or die "Can't connect to $conf->{'data_source'}.  $DBI::errstr";
    return $dbh;
}
1;

/*
 * Number Systems: Interconversion and arithmetic
 * Binary, Octal, Decimal, Hex
 * Compatible: It's supposed to be ANSI C, but I can't test it.
 * Distribute as you wish. Changes must be reported to Satya.
 * Please keep this section intact.
 * Written by Satya jam@comports.com http://satyaonline.cjb.net
 */

#include <stdio.h>
#define NUMBITS sizeof(unsigned)*8

void print_bin(unsigned foo); /*prints bin equiv of foo*/
unsigned scan_bin(void); /*returns decimal equiv of input bin num*/

void main(void) {

int menu=-1,target=-1; /*target-no. of numericals*/
void showmenu(void);
void convert(int target,int menu);

srand(time(NULL));
while(menu<0 || menu >12) {
	showmenu();
	printf("\nChoice: ");
	scanf("%d",&menu);
	}
while (target<0 || target>100) {
	printf("How many numericals? (0 for indefinite, or 1 to 100) ");
	scanf("%d",&target);
	}
if (menu==12) {convert(target,rand()%12);}
	else {convert(target,menu);}
printf("\nThanks for using Satya's Number Systems \
Conversions Tester\nversion 1.0 (Released on June 6 1999)\n\
Homepage: http://satyaonline.cjb.net/ Email: jam@comports.com");
exit(0);
} /* end main */

void convert(int target,int menu) {
int score=0,total=0;
unsigned num,ans;
char cont='Y';
while (toupper(cont)=='Y' && (target==0 || target>total)) {
	total++;
	num=rand()%1023;
	printf("%d. Convert ",total);
	switch(menu){
		case 0: case 1: case 2: printf("binary ");print_bin(num);break;
		case 3: case 4: case 5: printf("octal %o",num);break;
		case 6: case 7: case 8: printf("decimal %d",num);break;
		case 9: case 10: case 11: printf("hex %X",num);break;
		}
	printf(" to ");
	switch(menu){
		case 3: case 6: case 9: printf("binary");break;
		case 0: case 7: case 10: printf("octal");break;
		case 1: case 4: case 11: printf("decimal");break;
		case 2: case 5: case 8: printf("hex");break;
		}
	printf(". Answer: ");
	fflush(stdin);
	switch(menu){
		case 3: case 6: case 9: ans=scan_bin();break;
		case 0: case 7: case 10: scanf("%o",&ans);break;
		case 1: case 4: case 11: scanf("%d",&ans);break;
		case 2: case 5: case 8: scanf("%x",&ans);break;
		}
	if (ans==num) {
		printf("Correct!\n");
		score++;
		}
	else {
		printf("Sorry, correct answer is ");
		switch(menu){
			case 3:case 6:case 9:print_bin(num);printf("\n");break;
			case 0:case 7:case 10:printf("%o\n",num);break;
			case 1:case 4:case 11:printf("%d\n",num);break;
			case 2:case 5:case 8:printf("%X\n",num);break;
			}
		}
	if (target==0) {
		printf("More? ");
		fflush(stdin);
		scanf("%c",&cont);
		}
	}
printf("You got %d correct of a possible total of %d.\n",score,total);

} /* end convert */


unsigned scan_bin(void) {
char number[NUMBITS];
int pos=1;
unsigned c=0;
int i;
scanf("%s",number);
for(i=strlen(number)-1;i>=0;i--) {
	c+=((number[i]=='0'?0:1)*pos);
	pos*=2;
	}
return(c);
} /* end scan_bin */

void print_bin(unsigned num) {
int i;
unsigned mask=0x1<<(NUMBITS-2);
for(i=0;i<NUMBITS-1;i++) {
	printf("%d",mask&num?1:0);
	mask>>=1;
	}
} /* end print_bin */

void showmenu(void) {
	printf("\n0. Binary to octal\n");
	printf("1. Binary to decimal\n");
	printf("2. Binary to hex\n");
	printf("3. Octal to binary\n");
	printf("4. Octal to decimal\n");
	printf("5. Octal to hex\n");
	printf("6. Decimal to binary\n");
	printf("7. Decimal to octal\n");
	printf("8. Decimal to hex\n");
	printf("9. Hex to binary\n");
	printf("10. Hex to octal\n");
	printf("11. Hex to decimal\n");
	printf("12. Random type");
} /* end showmenu */

/* eof */
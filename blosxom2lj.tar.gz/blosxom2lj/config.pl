$mydir='/home/satyap/blosxom';
$user='satyap';
$pass=''; #must be md5sum

$datadir='/home/satyap/blosxom';
$ext='txt';

$datfile="$datadir/blosxom2lj.dat";
$find='/usr/bin/find';

$footer=''; # appended to end of every post made to LJ.

1;

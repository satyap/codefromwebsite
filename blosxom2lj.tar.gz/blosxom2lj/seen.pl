#!usr/bin/perl

use warnings;
use strict;

BEGIN{
require '/home/satyap/blosxom/config.pl';
use vars qw[$mydir $datadir $ext $datfile $find $md5sum];
push @INC,$mydir;
}

use LJPost;

my @files=`$find . -name "*.$ext" -print`;
my $sums;
my ($sum,$file);

$sums=LJPost::getsums($datfile);

foreach $file (@files) {
    chomp($file);
    $sum=LJPost::getmd5($file);
    next if (defined($sums->{$file}) && $sum eq $sums->{$file});
    print "$file $sum\n";
    $sums->{$file}=$sum;
    }

#delete elements from %sum which don't exist in $file;
my %s2;
foreach $file (@files) {
    $s2{$file}=$sums->{$file};
}

LJPost::writedat($datfile,\%s2);

exit;


__END__

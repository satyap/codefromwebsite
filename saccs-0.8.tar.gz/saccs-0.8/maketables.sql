/* list of accounts */
/* account type: 'b' for bank or 'c' for cc or 'm' for community */
/* climit is credit limit for credit card accounts */
create table accounts (
id int not null auto_increment,
name varchar(255),
actype char(2),
climit float,
primary key(id)
);

/* account is foreign key to accounts */
create table monthly (
id int not null auto_increment,
account int,
startdate date,
enddate date,
startamt float,
endamt float,
primary key(id)
);

create table details (
id int not null auto_increment,
account int,
ondate date,
descr varchar(255),
amt float,
cleared char(1),
primary key(id)
);
/* cleared=y or n */

create table people (
id int not null auto_increment,
account int,
name varchar(255),
primary key(id)
);

create table community (
id int not null auto_increment,
account int,
name int,
ondate date,
descr varchar(255),
amt float,
primary key(id)
);

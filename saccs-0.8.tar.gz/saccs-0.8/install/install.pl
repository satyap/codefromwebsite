#!/usr/bin/perl

use strict;
use warnings;
use ExtUtils::Install;
use ExtUtils::MakeMaker qw(prompt);
use Term::ReadKey;
use DBI;

#defaults
my $html='/var/www/html/saccs/';
my $base_html='/saccs/';
my $server_user='www-data';
my $dbhost='localhost';
my $dbuser='saccs';
my $db='saccs';
my $dbpass='';

my $argv0=$ARGV[0] || '';
my $cu=0;
if($argv0 eq 'cgi_update') {
    install({
            'cgi'=>$html,
        });
    exit;
}

my $conffile='saccsconf.pm';

my $response;
my $err;

$response=prompt('Where do you want to install the CGI files?',$html);
chomp($response);
if($response) {
    $html=$response;
}
if(substr($html,-1,1) ne '/') {
    $html.='/';
}

unless(-e $html) {
    print "$html does not exist\n";
    exit;
}

$response=prompt('What is the HTTP (browser) path?',$base_html);
chomp($response);
if($response) {
    $base_html=$response;
}

$response=prompt('What user does the web server run as?',$server_user);
chomp($response);
if($response) {
    $server_user=$response;
}

$response=prompt('What is the database host?',$dbhost);
chomp($response);
if($response) {
    $dbhost=$response;
}

$response=prompt('What is the database name?',$db);
chomp($response);
if($response) {
    $db=$response;
}

$response=prompt('What is the database username?',$dbuser);
chomp($response);
if($response) {
    $dbuser=$response;
}

print 'What is the database password? ';
print "\nPassword: ";
ReadMode("noecho");
$response=ReadLine(0);
ReadMode 0;
print "\n";
chomp($response);
unless($response) {
    print "Database password is required\n";
    exit;
}
$dbpass=$response;

$response=prompt('Shall I create the database tables now? (Make sure the database is created and the user given above has create permission)','n');
chomp($response);
$response=substr($response,0,1);
if(lc($response) eq 'y') {
#    my $dbh=DBI->connect(
#        "dbi:mysql:$db",
#        $dbuser,
#        $dbpass,
#        {
#            PrintError => 1,
#            RaiseError => 0,
#            AutoCommit => 0,
#        }
#    ) || die $DBI::errstr;
#    open(SQL,"maketables.sql") || die "maketables.sql: $!";
#    my $dbierr=0;
#    while(<SQL>) {
#        chomp;
#        next if /^\s*$/;
#        $dbh->do($_) || do {
#            print $DBI::errstr;
#            $dbierr=1;
#            $response=prompt("\nContinue?",'y');
#            $response=substr($response,0,1);
#            if(lc($response) eq 'n') {
#                exit;
#            }
#        }
#    }
#    close(SQL);
#    $dbh->disconnect;
    print `mysql -u $dbuser -h $dbhost -D $db --password='$dbpass' < maketables.sql`;
    #print `cat maketables.sql`;
}
else {
    print "Please create the tables in install/maketables.sql\n";
}

sleep(1);

install({
        'cgi'=>$html,
    });

#if(-e "${html}.htaccess") {
#    print "${html}.htaccess already exists, will not overwrite\n";
#}
#else {
#    open(HTACCESS,">${html}.htaccess") || die "$!";
#    print HTACCESS <<HTA;
#Options Indexes ExecCGI
#HTA
#    close(HTACCESS);
#}

open(CONF,">$html$conffile") || die "$!";
print CONF <<CONF;
package saccsconf;
require Exporter;
\@ISA=qw(Exporter);
\@EXPORT_OK=qw(\$dbd \$dbuser \$dbpass \$dbh \$html_root);
\$dbuser='$dbuser';
\$dbpass='$dbpass';
\$dbh='dbi:mysql:$db:$dbhost';
\$dbd = {
 PrintError => 1,
 RaiseError => 0,
 AutoCommit => 0
};
\$html_root="$base_html";
1;
CONF
close(CONF);

$err=`chown $server_user $html$conffile`;
if($err) {
    print $err;
}
$err=`chmod 600 $html$conffile`;
if($err) {
    print $err;
}


print "Done. \n";

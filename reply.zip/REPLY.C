#include <stdio.h>

#define NEWLINE '\n'

void main(int argc,char *argv[])	{
char buffer;
FILE *in,*out;
char *inf,*outf;

if (argc==3)	{
	inf=argv[1];
	outf=argv[2];
	}
else	{
	printf("Usage:");
	printf("\n\treply inputfilename outputfilename\n");
	exit(1);
	}

if ((in=fopen(inf,"rt"))==NULL) {
	printf("Error opening file %s\n",inf);
	exit(255);
	}
out=fopen(outf,"at");

while (!feof(in))	{
	buffer=fgetc(in);
	fputc(buffer,out);
	if (buffer==NEWLINE) {
		fputc('>',out);
		fputc(' ',out);
		}
	}

fclose(in);
fclose(out);
printf("End of Processing\nWritten by Satya jam@comports.com\n");
} /* main */

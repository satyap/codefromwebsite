#!/usr/local/bin/perl -w

use Socket;
use DBI;
require '/home/satyap/perl/mailman/settings.pl';

sub mail_parse()	{

my $echo='/bin/echo';
my $formail='/usr/bin/formail';

#this had better produce a good return address.

my @ary; #return this
my @mailonstdin; #the entire email
my $header=1;

while($line=shift)	{
	push (@mailonstdin,$line);
	}

push(@ary,'from');

$msg='';
foreach $line (@mailonstdin)	{
	if($line=~/^$/)	{last}
	if ($line=~/^From:/) {$msg=$line}
	}
push(@ary,`$echo "$msg"|$formail -rtzxTo:`);

$header=1;
foreach $line (@mailonstdin)	{
	if($line=~/^$/)	{$header=0}
	chomp($line);
	if($header && $line=~/^Subject:/)	{
		push(@ary,'subject');
		$line=~s/^Subject: //;
		push(@ary,$line);
		}
	if($header && $line=~/^To:/)	{
		push(@ary,'to');
		$line=~s/^To: //;
		push(@ary,$line);
		}
	if(!$header && $line=~/[a-zA-Z0-9]*?=.*/)	{
		push(@ary,split(/=/,$line,2));
	}
} #foreach


return(@ary);

} #sub mail_parse


sub parse_addr()	{
my $pa_addr=shift;
$pa_addr=~s/(.*)(<|\s)(.*?\@.*?)(>|\s)(.*)/$3/;
return $pa_addr;
} #sub parse_addr()


sub dbOpen()	{
	$dbh=DBI->connect("dbi:mysql:mailman",$dbuser,$dbpass,
				{
				AutoCommit=>1
				}
			) 
	|| do{throw("$DBI::errstr")};
}

sub dbClose()	{
	$dbh->disconnect();
}

sub dbCursor()	{
	$func_sql=shift;
	$cursor=$dbh->prepare($func_sql) || do	{
		throw("Database error in cursor create<br>$DBI::errstr");
		};
	$cursor->execute || do	{
		throw("Database error in cursor execute<br>$DBI::errstr");
		};
}

sub dbCloseCursor	{
	$cursor->finish;
}

sub dbFetch()	{
	$cursor->fetchrow_hashref;
}

sub dbQuote()	{
	$dbh->quote(shift);
}

sub dbDo($)	{
	$dbh->do(shift);
}


sub mail_send($,$,$)	{

my $funcfrom=shift;
my $functo=shift;
my $funcmsg=shift;
my $reply;


my $iaddr = inet_aton('localhost') or
	die "Could not resolve localhost: $!";
my $paddr = sockaddr_in(25, $iaddr);
my $proto = getprotobyname('tcp');
socket(MAIL, PF_INET, SOCK_STREAM, $proto) or
	die "Could not open client tcp socket: $!";
connect(MAIL, $paddr) or
	die "Could not connect socket to server: localhost:25: $!";
while( ($reply = <MAIL>) =~ /^\d\d\d-/ ) {}
do {
	close MAIL or warn "Could not close socket with localhost: $!";
	die "Server did not respond with 220 on connect: $reply";
} if $reply !~ /^220/;

select MAIL; $|=1; select STDOUT;
print MAIL "helo localhost\n";
$reply=<MAIL>;
print MAIL "mail from:$funcfrom\n";
$reply=<MAIL>;
print MAIL "rcpt to:$functo\n";
$reply=<MAIL>;
print MAIL "data\n";
$reply=<MAIL>;
print MAIL "$funcmsg";
print MAIL "\n.\n";
$reply=<MAIL>;
close(MAIL)     || die("Error closing mail port");

} #sub mail_send

sub throw()	{
if (defined($dbh))      {dbClose()}
exit;

} #sub throw

1;

__END__

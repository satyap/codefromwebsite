#!/usr/local/bin/perl -w

=item whatisthis
Stand-alone script to receive requests from unsub.html and forward them to
the address in $to

See below for configuration.
=cut

use strict;
use CGI;

#where is sendmail?
my $mailpath='/usr/sbin/sendmail -t';

#which address receives these messages (procmail target)
my $to='mailman-procmail@satya.virtualave.net';

## end config

print "Content-type: text/html\n\n";

my $q=new CGI;

print <<HTML;
<html>
<head>
</head>
<body bgcolor="#ffffff" text="#000000">

You are unsubscribing from:<P>
HTML

foreach ($q->param('lists'))	{
open(MAIL,"|$mailpath -t") || do        {
        print "Error opening mail connection, aborted<P>$!";
        die "Mail open error: $!";
        };
print MAIL "From: $to\nTo: $to\n";
print MAIL "Subject: Mailman unsub request\n\n";
print MAIL "list=$_\nemail=";
print MAIL $q->param('email'), "\naction=unsub\n\n.\n";
close(MAIL);

print "$_<br>";

} #foreach

print<<HTML;
<P>
Thanks. Expect a confirmation message soon.
HTML

print '</body></html>';


__END__

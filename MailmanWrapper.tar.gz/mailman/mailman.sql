# MySQL dump 5.13
#
# Host: localhost    Database: mailman
#--------------------------------------------------------
# Server version	3.22.30

#
# Table structure for table 'codes'
#
CREATE TABLE codes (
  confirmcode int(8),
  email varchar(60),
  list varchar(100),
  action char(1),
  tstamp date
);

#
# Table structure for table 'lists'
#
CREATE TABLE lists (
#public list posting address list@example.com
  list varchar(60),
#listadmin's address admin@example.org
  admin varchar(60),
#list's actual subscribe address as recognized by MTA and mailman
#list-request@localhost
  subscribe varchar(60),
#list's actual unsubscribe address as recognized by MTA and mailman
#list-request@localhost
  unsubscribe varchar(60),
#list's confirmation address to which users can send confirmation message,
#likely to be defined in procmailrc or wherever. mailman does not know
#this address. list-confirm@example.com
  confirm varchar(60),
  id int(8) DEFAULT '0' NOT NULL auto_increment,
  PRIMARY KEY (id)
);

#
# Table structure for table 'subs'
#
CREATE TABLE subs (
  id int(8),
  email varchar(60)
);


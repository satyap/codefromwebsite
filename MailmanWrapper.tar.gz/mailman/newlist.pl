#!/usr/local/bin/perl -w

use DBI;
use strict;
require 'functions.pl';

my $mailmanwrapper='$HOME/perl/mailman';
my $perlpath='$PERL';

my ($list,$owner,$lname,$domain,$sql);

print "Enter list address: ";
$list=<STDIN>;
chomp($list);
print "Enter list owner address: ";
$owner=<STDIN>;
chomp($owner);

($lname,$domain)=split('@',$list);

dbOpen();

$sql='insert into lists (list,admin,subscribe,unsubscribe,confirm) values(';

$sql.=dbQuote($list).','.dbQuote($owner).',';
$sql.=dbQuote($lname.'-request@localhost').',';
$sql.=dbQuote($lname.'-request@localhost').',';

$sql.=dbQuote($lname.'-confirm@'.$domain).')';

print "\n$sql\n";

if(dbDo($sql)<1)	{
#if(1==0)	{
	print "$DBI::errstr\n";
	}
else	{
	print "$DBI::errstr\n";
print "Hit enter when ready";
$owner=<STDIN>;
	print "Procmail:\n";
	print<<PROCMAIL;
:0:
* ^TO_$lname(\@|-.*@)$domain
{
:0 c: $lname.lock
mail/$lname
:0: $lname.dupes
* ^(List-Id|Resent-From):.*$lname
mail/duplicates
:0:
* ^TO_$lname-request\@$domain
! $lname-request\@localhost
:0:
* ^TO_$list
! $lname\@localhost
:0:
* ^TO_$lname-(owner|admin)\@$domain
! $lname-owner\@localhost
:0:
* ^TO$lname-remove
| $perlpath $mailmanwrapper/unsubscribe.pl $list
:0:
* ^TO$lname-subscribe
| $perlpath $mailmanwrapper/subscribe.pl $list
:0:
* ^TO$lname-confirm
| $perlpath $mailmanwrapper/confirm.pl
}
PROCMAIL
	} 

dbClose();

__END__

#!/usr/local/bin/perl -w

#this ain't pod, it's just a comment
=item description

Takes a properly formatted (see README and the HTML files) mail on STDIN,
else requires the list post address on the command line 

=cut

use strict;
use DBI;
require '/home/satyap/perl/mailman/functions.pl';
require '/home/satyap/perl/mailman/templates.pl';
use vars qw[$site $admin $check_subs $id];

my ($foo, $sql, $msg, $confirmcode, $confirm, $rows);
my $listadmin='';

my %data=mail_parse(<STDIN>);

my $list=$data{'list'} || $ARGV[0] || '';
my $replyto=$data{'email'} || $data{'from'} || $admin;
my $email=$data{'email'} || $data{'from'} || '';

if ($list eq '' || $email eq '' || $email eq 'foo@bar')	{
	mail_send($admin,$replyto,msgunsub($site,$admin));
	mail_send($admin,$admin,msgunsub($site,$admin)."\n$0\nno list, no email, or bad email");
	throw();
	}

dbOpen();



#get unsubscribe confirm and listadmin addresses
$sql='select * from lists where list='. dbQuote($list);
dbCursor($sql);
while($rows=dbFetch())	{
	$confirm=$rows->{'confirm'};
	$listadmin=$rows->{'admin'};
	$id=$rows->{'id'};
		}
dbCloseCursor();


#if listadmin doesn't exist, maybe the mailing list doesn't exist
if($listadmin eq '')	{
	mail_send($admin,$email,msgnolist($list,$site,$admin));
	mail_send($admin,$admin,"no listadmin found\n$0\n\n".msgnolist($list,$site,$admin));
	throw();
	}

#find out if the user is subscribed to the list

if ($check_subs==1)	{ #check subscriber list?
	$sql="select * from subs where id=$id and email=" . dbQuote($email);
	unless(dbDo($sql)!=0)	{
		mail_send($listadmin,$email,msgnotsubbed($site,$list,$email,$listadmin));
		mail_send($admin,$listadmin,msgnotsubbed($site,$list,$email,$listadmin)."\n$0\nchecked subscriber list; this address isn't there");
		exit;
		}
	} #check_subs

srand(time);

#generate a random confirm code which doesn't already exist
do	{
$confirmcode=sprintf("%8.0f",rand()*100000000);
$sql='select confirmcode from codes where confirmcode=' .
	dbQuote($confirmcode)
} while(dbDo($sql)>0);


$msg=<<MSG;
To: $email
Subject: Confirm unsubscribe: $confirmcode

You have requested to unsubscribe from the list $list

Please confirm this action by replying to this message. Keep the
Subject: line intact. It must contain this code:

        $confirmcode

In most email programs, simply replying to this message will confirm
that you want to leave the list $list

If you do not want to leave $list, ignore this message.

For any clarifications, contact $listadmin
MSG

#save the code, so we can check it later
$sql='insert into codes (confirmcode,email,list,action,tstamp) values (';
$sql.="$confirmcode, ";
$sql.=dbQuote($email) .','. dbQuote($list) .','. "'u' , now())";

$rows=dbDo($sql);

if($rows<1)	{
	mail_send($admin,$admin,
"\nMailman db failure inserting into codes: email=$email".
"\nconfirmcode=$confirmcode \nlist=$list\n\n".$DBI::errstr."\n\n$0\n");
	throw();
	}

mail_send($confirm,$email,$msg);

dbClose();

__END__

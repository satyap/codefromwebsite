#Mysql database user
$dbuser='satyap';

#mysql database password
$dbpass='SET_ME';

#Site password for mailman
$site_pass='SET_ME';

#Site admin email address -- used as last resort
$admin='mailman-admin@satya.virtualave.net';

#FQDN of this site
$site='satya.virtualave.net';

#Do we have a list of known subscribers to check unsub requests?
# 0=no 1=yes
$check_subs=1;

1;

__END__

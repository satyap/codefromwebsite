#!/usr/local/bin/perl -w

use strict;
use DBI;
require '/home/satyap/perl/mailman/functions.pl';
require '/home/satyap/perl/mailman/templates.pl';
use vars qw[$site $admin $site_pass];

my ($foo, $sql, $msg, $confirmcode, $confirm, $rows);
my ($email, $list, $addr);
my $action='';

my %data=mail_parse(<STDIN>);

my $subject=$data{'subject'} || '';
my $to=$data{'from'} || $data{'$admin'};

dbOpen();

dbCursor('select * from codes');
while($rows=dbFetch())	{
	$confirmcode=$rows->{'confirmcode'};
	if ($subject=~/$confirmcode/)	{
		$action=$rows->{'action'};
		$email=$rows->{'email'};
		$list=$rows->{'list'};
		} #if
	} #while
dbCloseCursor();

if ($action eq '')	{
	mail_send($admin,$to,msgbadconfirm($site,$admin));
	mail_send($admin,$admin,msgbadconfirm($site,$admin)."\n$0: no action");
	throw();
	}

if($action eq 's')	{$action='subscribe';$email='address='.$email}
if($action eq 'u')	{$action='unsubscribe'}

$sql='select * from lists where list=' . dbQuote($list);
dbCursor($sql);
while($rows=dbFetch())	{
	$addr=$rows->{"$action"};
	} #while

$msg=<<MSG;
Subject: $action $site_pass $email

$action $site_pass $email
MSG

#print "\nTo: $addr\nfrom: $email\nmsg:\n*$msg*\n";

mail_send($admin,$addr,$msg);

#cleanup old entries
$sql='delete from codes where to_days(now())-to_days(tstamp)>60';
dbDo($sql);

dbClose();

__END__

#!/usr/local/bin/perl -w

=item comment

Okay, this one takes a blank (or otherwise) message to list-subscribe and
constructs a proper list-request message.

=cut

use strict;
use DBI;
require '/home/satyap/perl/mailman/functions.pl';
require '/home/satyap/perl/mailman/templates.pl';


use vars qw[$site $admin $check_subs];

my ($sql, $msg, $request, $rows, $id);
my $listadmin='';

my %data=mail_parse(<STDIN>);

#my $list=$data{'list'} || '';
my $list=$ARGV[0];
my $email=$data{'email'} || $data{'from'};
my $replyto=$data{'replyto'} || $data{'from'} || $admin;

print $list,$email;

if ($list eq '' || $email eq '')	{
	mail_send($admin,$replyto,msgsub($site,$admin));
	mail_send($admin,$admin,msgsub($site,$admin)."\n\n$0\nlist: $list\nemail: $email\nerror: list or email is blank");
	throw();
	}

dbOpen();


#get list-request and admin addresses
$sql='select * from lists where list='. dbQuote($list);
dbCursor($sql);
while($rows=dbFetch())	{
	$request=$rows->{'subscribe'};
	$listadmin=$rows->{'admin'};
	$id=$rows->{'id'};
	}
dbCloseCursor();

if($listadmin eq '')	{
	mail_send($admin,$email,msgnolist($list,$site,$admin));
	mail_send($admin,$admin,msgnolist($list,$site,$admin)."\n$0\nerror: no such list");
	throw();
	}

if($check_subs)	{
#find out if the user is subscribed to the list
$sql='select * from subs where email=';
$sql.=dbQuote($email) . 'and id=';
$sql.=dbQuote($id);

if(dbDo($sql)>0)	{
	mail_send($listadmin,$email,msgalreadysubbed($list,$listadmin));
	mail_send($admin,$listadmin,msgalreadysubbed($list,$listadmin)."\n$0\nerror: already subscribed");
	throw();
	}
}

$msg="Subject: subscribe\n\nsubscribe\n";

mail_send($email,$request,$msg);

dbClose();

__END__

sub msgunsub()	{
$site=shift;
$admin=shift;
<<MSG;
Subject: Direction unclear

This is the Mailman wrapper at $site

Your commands were not understood.

To remove yourself from a list at $site,
send a blank email to (listname)-remove\@$site

where (listname) is the name of the list.

Contact $admin for clarifications.
MSG
}


sub msgsub()	{
$site=shift;
$admin=shift;
<<MSG;
Subject: Direction unclear

This is the Mailman wrapper at $site

To add yourself to a list at $site,
send a blank email to (listname)-subscribe

where (listname) is the name of the list.

Contact $admin for clarifications.
MSG
}

sub msgnotsubbed()	{
$site=shift;
$list=shift;
$email=shift;
$listadmin=shift;
<<MSG;
Subject: Not a member of $list

This is the Mailman wrapper at $site

You ($email) have requested to leave $list

Our records show that you are not a member of $list

Perhaps you are registered under a different address?

If you registered within the last 1 hour, or have not yet confirmed your
registration, please try again after 1 hour. It takes 1 hour for our
records to update.

Contact $listadmin for clarifications.
MSG
}

sub msgnolist()	{
$list=shift;
$site=shift;
$admin=shift;
<<MSG;
Subject: $list not found

This is the Mailman wrapper at $site

Our records show that $list does not exist at this site.

Perhaps you are looking for some other site?

Contact $admin for any clarifications.
MSG
}

sub msgbadconfirm()	{
$site=shift;
$admin=shift;
<<MSG;
Subject: Your recent message to mailman at $site

Your confirmation code was not recognized.

Contact $admin for any clarifications.
MSG
}

sub msgalreadysubbed()	{
$list=shift;
$listadmin=shift;
<<MSG;
Subject: You are already subscribed to $list

Our records indicate that you are already subscribed to $list

For any clarifications, contact $listadmin
MSG
}
1;

__END__

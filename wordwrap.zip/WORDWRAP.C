#include <stdio.h>

#define NEWLINE '\n'

void main(int argc,char *argv[])	{
char buffer;
int maxline,thisline,flag;
	/*flag=1 if current character is an enter mark or space*/
FILE *in,*out;
char *inf,*outf;

if (argc==3)	{
	inf=argv[1];
	outf=argv[2];
	}
else	{
	printf("Usage:");
	printf("\n\twordwrap inputfilename outputfilename");
	printf("\nYou will be asked to enter the maximum output line length.");
	printf("\nThis is not exact; the actual lines will end somewhere *nearby*.");
	printf("\n\nFreeware Wordwrapper by Satya jam@comports.com\n");
	exit(1);
	}

printf("Enter the maximum line length: ");
scanf("%d",&maxline);
if (maxline<25 || maxline>200)	{
	printf("Huh? I can't do that.");
	}

if ((in=fopen(inf,"rt"))==NULL) {
	printf("Error opening file %s\n",inf);
	exit(255);
	}
out=fopen(outf,"at");

thisline=0;
while (!feof(in))	{
	buffer=fgetc(in);
	fputc(buffer,out);
	if (buffer==NEWLINE)	{thisline=0;flag=1;}
	if (buffer==' ')	flag=1;
	if (buffer!=' ' && buffer!=NEWLINE) flag=0;
	thisline++;
	if (thisline>maxline-1 && flag==1) {
		fputc('\n',out);
		thisline=0;
		flag=0;
		}
	}

fclose(in);
fclose(out);
printf("End of Processing\n");
printf("Thanks for using Satya's Wordwrapper ver2.0. This is freeware.\n");
} /* main */

#!/usr/bin/perl
#
#By Satya satyap@satyaonline.cjb.net
#Takes out a fortune from the fortune database and displays it.
#or can display all fortunes from a specific set.
#Call as any of:
#<a href="/cgi-bin/fortune.pl">Random fortune</a><br>
#<a href="/cgi-bin/fortune.pl?art">art</a>
#<a href="/cgi-bin/fortune.pl?all-art">all art</a>
#The parameter has to be a name of a fortune file. Don't put .dat files!
#

print "Content-type: text/html\n\n";

$file=$ENV{"QUERY_STRING"};

if (substr($file,0,4) eq "all-")	{
	$file=substr($file,4,length($file));
	$fortune=`cat /usr/share/games/fortunes/$file`;
	$fortune=~s/\n%\n/\n<hr>\n/g;
	}
else	{
	$fortune=`/usr/games/fortune $file`;
	}

print "<html><head><title>";
print "Random fortunes -- $file";
print '</title></head><body bgcolor="#ffffff" text="#000000">';
print "\n<prE>\n$fortune\n</pre>\n";
print '</body></html>';

#EOF
